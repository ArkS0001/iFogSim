package org.cloudbus.cloudsim.util;

public class Test2 {
	public Test t;
	public String st;
	
	public Test2(int i){
		t = new Test(i);
		st = new String("PP");
	}
}
